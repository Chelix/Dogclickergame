var points = 0;
var time= 200;
var items = 0;
displaygame();
function displaygame() {
  setText("Score_display", 0);
  setText("Timedisplay", time);
  restartitems();
  numberrestart();
  showelement();
}
function continuedisplay() {
   setText("Score_display", 0);
  setText("Timedisplay", time);
  restartitems();
   showelement();
}
function numberrestart() {
  points = 0;
  items = 0;
  time = 200;
}
function Continuedgame() {
  restartitems();
  showelement();
  items = 0;
  points = 0;
  if (time==200) {
    time = time-10;
  } else {
    if (time==190) {
      time = time-40;
    }
    if (time==150) {
      time = 100;
    }
  }
}
function restartitems() {
  setText("Itemscore", items);
  setText("Dogbiscuitbought", "");
  setText("DogBrushbought", "");
  setText("Tennisballbought", "");
}
function showelement() {
  showElement("Buyitem1");
  showElement("Buyitem2");
  showElement("Buyitem3");
}
onEvent("Go_store", "click", function( ) {
  setScreen("Shopscreen");
});
onEvent("Gobackgame", "click", function( ) {
  setScreen("Gamescreen");
});
timedLoop(950, function() {
  setText("Timedisplay", time);
  time = time-1;
  if (time==0) {
    setScreen("Gameover");
  }
});
setText("Pointshop", points);
onEvent("Go_store", "click", function( ) {
  Shopbutton();
});
onEvent("Dogicon", "click", function( ) {
  points = points+1;
  setText("Score_display", points);
  setText("Pointshop", points);
});
Dogmove();
function Dogmove() {
  timedLoop(2000, function () {
    setPosition("Dogicon", randomNumber(0, 250), randomNumber(0, 300), 150, 150);
  });
}
function Shopbutton() {
  if (points < 20) {
    setProperty("Buyitem1", "background-color", "grey");
  } else {
    setProperty("Buyitem2", "background-color", "blue");
  }
  if (points < 30) {
    setProperty("Buyitem2", "background-color", "grey");
  } else {
    setProperty("Buyitem2", "background-color", "red");
  }
  if (points < 50) {
    setProperty("Buyitem3", "background-color", "grey");
  } else {
    setProperty("Buyitem3", "background-color", "blue");
  }
}
onEvent("Buyitem1", "click", function( ) {
  if (points<20) {
    Shopbutton();
  } else {
    Shopbutton();
    points = points-20;
    items = items+1;
    setText("Itemscore", items);
    setText("Pointshop", points);
    setText("Dogbiscuitbought", "Bought");
    setText("Score_display", points);
    hideElement("Buyitem1");
  }
});
onEvent("Buyitem2", "click", function( ) {
  if (points<30) {
    Shopbutton();
  } else {
    Shopbutton();
    points = points-30;
    items = items+1;
    setText("Itemscore", items);
    setText("Pointshop", points);
    setText("Tennisballbought", "Bought");
    setText("Score_display", points);
    hideElement("Buyitem2");
  }
});
onEvent("Buyitem3", "click", function( ) {
  if (points<50) {
    Shopbutton();
  } else {
    Shopbutton();
    points = points-50;
    items = items+1;
    setText("Itemscore", items);
    setText("Pointshop", points);
    setText("DogBrushbought", "Bought");
    setText("Score_display", points);
    hideElement("Buyitem3");
  }
});
onEvent("Wingame", "click", function( ) {
  if (items==3) {
    setScreen("Winscreen");
  }
});
onEvent("Playagain", "click", function( ) {
  Continuedgame();
  continuedisplay();
  time = time-10;
  setText("Score_display", points);
  setScreen("Gamescreen");
});
onEvent("Try_again", "click", function( ) {
  displaygame();
  setText("Score_display", points);
  setScreen("Gamescreen");
});
